# easy-youtube-batch-uploader
<img width="1536" height="1024" alt="image" src="https://github.com/user-attachments/assets/03479dc8-3313-4f49-9221-919ffd57e465" />

`easy-youtube-batch-uploader` automates a typical dashcam workflow:
- batch upload videos to YouTube with OAuth and READY/DONE staging

## Quick Start (npm CLI)

```bash
npm install -g easy-youtube-batch-uploader
easy-youtube-batch-uploader init
easy-youtube-batch-uploader setup
easy-youtube-batch-uploader doctor
```

`init` is non-interactive (safe to re-run, preserves values, fills missing keys).
`setup` is interactive and asks for config values in terminal (like Next.js style setup).

Then:
1. Edit the config file printed by `init` (default: `~/.config/easy-youtube-batch-uploader/config.env`)
2. Put videos in your configured `SOURCE` folder
3. Run `easy-youtube-batch-uploader upload`

## Requirements

- macOS or Linux
- Windows via WSL2 (recommended) or Git Bash
- Node.js `>=18`
- `bash`, `python3`
- Google Cloud OAuth desktop client JSON (for YouTube upload)

Native Windows `cmd`/PowerShell is not officially supported in this release.

## Commands

```bash
easy-youtube-batch-uploader init
easy-youtube-batch-uploader setup
easy-youtube-batch-uploader doctor
easy-youtube-batch-uploader upload

# Short alias:
eybu init
eybu setup
eybu doctor
eybu upload
```

## OAuth Behavior

- On first `upload`, browser OAuth login opens.
- User selects their Google/YouTube (or Brand) account.
- Token is saved to `GOOGLE_TOKEN_FILE`.
- Next uploads reuse saved token until revoked/expired.

## Config Location

- Default config file: `~/.config/easy-youtube-batch-uploader/config.env`
- Override path if needed with `EYBU_ENV_FILE=/your/path/config.env`

## Environment Variables

Copy from `.env.example` and adjust:

- `SOURCE`: folder to read videos from (usually SD card mount path)
- `YT_TITLE_PREFIX`: prefix for generated video titles
- `YT_DESCRIPTION`: default YouTube description
- `YT_CATEGORY_ID`: YouTube category (default `2`)
- `YT_PRIVACY`: `private`, `unlisted`, or `public`
- `READY_TAG` / `DONE_TAG`: filename tags used by upload flow
- `GOOGLE_CLIENT_SECRETS`: path to OAuth client JSON
- `GOOGLE_TOKEN_FILE`: token cache path
- `YT_TARGET_CHANNEL_ID` (optional but recommended): safety lock to enforce target channel
- `YT_PLAYLIST_ID` (optional): auto-add uploads to a playlist

You only need to run `upload`. Import/combine flow has been removed.

## Sample Screenshots

<img width="842" height="741" alt="sample screenshot 1" src="https://github.com/user-attachments/assets/d9f439bf-9771-4058-a902-d65d30165e89" />
<img width="293" height="689" alt="sample screenshot 2" src="https://github.com/user-attachments/assets/bc00fbef-a999-451c-bd86-715a9bacdc19" />
